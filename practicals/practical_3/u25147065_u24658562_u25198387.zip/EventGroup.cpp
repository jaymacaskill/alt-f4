// Dian le Roux (25147065)
// Marko de Swardt (24658562)
// Jay Macaskill (25198387)

// COS 214 (Software Modelling) Practical 3
// Last Modified: 31 August 2026

// EventGroup.cpp

#ifndef EVENTGROUP_CPP
#define EVENTGROUP_CPP

#include "EventGroup.h"
#include "Subject.h"
#include "EventComponent.h"
#include "Notice.h"

#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

EventGroup::EventGroup(const string& name) : Subject() // is also a subject, dont call EventComp constr cuz it doesnt have one
{
	this->name = name;
}

void EventGroup::add(EventComponent* child)
{
	if (child == nullptr)
	{
		return;
	}

	// dupe check
	if (find(children.begin(), children.end(), child) != children.end())
	{
		return; // already owned by this group, we avoid double ownership/double free so it doesnt have dupe children
	}

	// Composite side
	children.push_back(child); // 'this' owns this childs lifetime now

	// Observer side
	this->attach(child); // every child added to the group is auto registered to hear the groups notices
}

const string& EventGroup::getName()
{
	return this->name;
}

// doesnt destrow the child, only detach it
EventComponent* EventGroup::remove(EventComponent* child)
{
	if (child == nullptr)
	{
		return nullptr;
	}

	auto it = find(children.begin(), children.end(), child);

	if (it == children.end())
	{
		cout << "Could not remove an unrecognised component from " << this->name << ".\n";
		return nullptr;
	}

	children.erase(it); // removes the ownership relationshp
	this->detach(child); // remove observer registration, call code from Subject class

	return child; // return ptr instead of delete,

}

// for a group it will open the whole tree 
void EventGroup::open()
{
	cout << this->name << " is now open.\n";

	this->isOpen = true;

	for (EventComponent* child : children)
	{
		child->open();
	}
}

void EventGroup::close()
{
	cout << this->name << " is now closed.\n";
	this->isOpen = false;

	for (EventComponent* child : children)
	{
		child->close();
	}
}

void EventGroup::reportStatus()
{
	cout << this->name << ": " << (this->isOpen ? "OPEN" : "CLOSED")
	    << " (" << this->getCapacity() << " total capacity)\n";

	for (EventComponent* child : children)
	{
		child->reportStatus(); //gives report status for each child
	}
}

int EventGroup::getCapacity()
{
	int total = 0;

	for (EventComponent* child : children)
	{
		total += child->getCapacity(); //adds for each child, recursive
	}

	return total;
}

int EventGroup::getOccupancy()
{
	int total = 0;

	for (EventComponent* child : children)
	{
		total += child->getOccupancy();
	}

	return total;
}

void EventGroup::checkCapacity(int threshold) {

	if (this->getOccupancy() >= threshold)
	{
		cout << this->name << " has reached its capacity threshold (" << this->getOccupancy() << "/" << threshold << ") and is raising a capacity alert.\n";

		Notice alert;
		alert.type = CAPACITY_ALERT;

		alert.message = this->name + " has reached its capacity threshold.";
		this->notify(alert); // will reach each childs 'update(notice)', its a cascading pattern triggered by this condition/if-statement
	}
	else
	{
		cout << this->name << " is within its capacity threshold (" << this->getOccupancy() << "/" << threshold << ").\n";
	}

}

void EventGroup::update(Notice& notice)
{
	// Track this group's own state
	switch (notice.type)
	{
		case OPEN:
			this->isOpen = true;
			break;

		case CLOSE:
			this->isOpen = false;
			break;
		
		case EVACUATE:
			this->isOpen = false;
			break;

		default:
			break;
	}

	// If a child is an EventGroup, this recurses further down the tree
	// if a child is an EventUnit leaf, its own update() gets called. this causes the cascading
	this->notify(notice);
}

void EventGroup::transfer(EventGroup* new_parent, EventComponent* unit)
{
	if (new_parent == nullptr || unit == nullptr)
		return;

	if (find(children.begin(), children.end(), unit) == children.end())
	{
		cout << unit->getName() << " is not owned by " << this->name << ". Transfer aborted.\n";
		return;
	}

	this->remove(unit); // detaches `unit` as an observer of this group
	new_parent->add(unit); // re attaches `unit` as an observer of its NEW owner, since it got transferred

	cout << unit->getName() << " has been transferred from " << this->name
	    << " to " << new_parent->getName() << ".\n"; //display a success message
}

EventGroup::~EventGroup()
{
	// free whole subtree, calls delete on all pointers in 'children'
	for (EventComponent* child : children)
	{
		delete child;
	}

	children.clear();
}

#endif // EVENTGROUP_CPP